__author__ = 'svobik'

#import xml.etree.ElementTree as ET
import os
from Dict import Dict
import Word
import xml.etree.cElementTree as ET
from fnmatch import fnmatch
from xml.dom.minidom import parse
import xml.dom.minidom
import csv, sys, codecs, cStringIO
from CsvWriter import UnicodeWriter


root = '/media/data/korpusy/PDT/korpus/mw'
root2 = '/media/data/korpusy/Czech_WordNet'
pattern = "*.m"
pattern2 = "*.xml"
#newWord = Word("ahoj")

headers = ['literal', 'antonym']
filename = 'antonym.csv'
f = codecs.open(filename, encoding='utf-8', mode='w+')
w = UnicodeWriter(open(filename.replace('.csv', '.noun.csv'), 'w'), headers)
w.writerow(dict([(h,h) for h in headers]))



def write_file(lines,fname):
    wf = open(fname, 'wb')
    wf.writelines(lines)
    wf.close()

def find_in_tree(tree, node):
    found = tree.find(node)
    if found == None:
        print "No %s in file" % node
        found = []
    return found

def extract_nbr(input_str):
    if input_str is None or input_str == '':
        return 0

    out_number = []
    for t in input_str.split("-",2):
        try:
            out_number.append(float(t))
        except ValueError:
            pass
    return out_number


antonyms_found = 0
data = Dict()



for path, subdirs, files in os.walk(root2):
    for name in files:
        if fnmatch(name, pattern2):
            print os.path.join(path, name)
            f = open(path+"/"+name, 'r')
            DOMTree = xml.dom.minidom.parse(f)
            collection = DOMTree.documentElement

            synset = collection.getElementsByTagName("SYNSET")
            #rootElement = ET.parse(path+"/"+name).getroot()
            #xmldoc = minidom.parse(path+"/"+name)
            #itemList = xmldoc.getElementsByTagName('SYNSET')

            print(len(synset))
            for s in synset:
                id = s.getElementsByTagName("ID")[0]
                number_id = extract_nbr(id.childNodes[0].data)
                if (len(number_id)>0):
                    #print "ID: %d" % number_id[0]
                    literal = s.getElementsByTagName('LITERAL')[0]
                    #print "Literal: %s" % literal.childNodes[0].data
                    data[int(number_id[0])] = literal.childNodes[0].data
                #data = data + {int(number_id[0]):literal.childNodes[0].data}

            for s in synset:
                if s.getElementsByTagName('ILR'):
                    #typeElements = s.getElementsByTagName('ILR')
                    #type = s.getElementsByTagName('ILR')[0]
                    ilr = s.getElementsByTagName('ILR')
                    for antonym in ilr:
                        if antonym.getElementsByTagName('TYPE'):
                            antonymCheck = antonym.getElementsByTagName('TYPE')[0]
                            if (antonymCheck.childNodes[0].data == "near_antonym"):
                                print "IDofAntonym: %s" % antonym.childNodes[0].data
                                literal = s.getElementsByTagName('LITERAL')[0]
                                literalID = antonym.childNodes[0].data
                                print "Literal: %s" % literal.childNodes[0].data
                                number_id = int(extract_nbr(antonym.childNodes[0].data)[0])
                                literal_antonym = data[number_id]
                                print " %s %s" % (literal.childNodes[0].data,literal_antonym)
                                if (literalID[-1]== 'n'):
                                    w.writerow({"literal":literal.childNodes[0].data, "antonym":literal_antonym})

                                #csvWriter.writerow([literal.childNodes[0].data,literal_antonym])

                                antonyms_found += 1
            #for child in rootElement.findall('tag'):
             #   rank = child.find('AAFS2----1A----').text
             #   print child.attrib



print(antonyms_found)