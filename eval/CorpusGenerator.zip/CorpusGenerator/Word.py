__author__ = 'svobik'

class Word(object):


    def __init__(self, id, lemma):
        self.id = id
        self.lemma = lemma
        self.antonyma = ""
        self.falls = []
        self.phase = []
    def addFirstFall(self, newFall):
        #self.falls.append(newFall)
        self.falls[0] = newFall
    def addSecondFall(self, newFall):
        self.falls[1] = newFall
    def addThirdFall(self, newFall):
        self.falls[2] = newFall
    def addPhase(self, newPhase):
        self.phase.append(newPhase)
    def returnFalls(self):
        return self.falls
    def setAntonyma(self, antonyma):
        self.antonyma = antonyma
    def getAntonyma(self):
        return self.antonyma