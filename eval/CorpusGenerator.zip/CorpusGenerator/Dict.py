__author__ = 'svobik'

class Dict(dict):
    def __add__(self, other):
        copy = self.copy()
        copy.update(other)
        return copy
    def __radd__(self, other):
        copy = other.copy()
        copy.update(self)
        return copy