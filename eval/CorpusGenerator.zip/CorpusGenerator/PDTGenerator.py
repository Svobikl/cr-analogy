__author__ = 'svobik'

__author__ = 'svobik'

#import xml.etree.ElementTree as ET
import os
from collections import defaultdict
import Word
import xml.etree.cElementTree as ET
from fnmatch import fnmatch
from xml.dom.minidom import parse
import xml.dom.minidom
import collections
import csv, sys, codecs, cStringIO
from CsvWriter import UnicodeWriter


root = '/media/data/korpusy/PDT/korpus/mw'
pattern = "*.m"
pattern2 = "*.xml"
#newWord = Word("ahoj")

headers = ['podst.jm', 'plural']
filename = 'podst.jm.csv'
f = codecs.open(filename, encoding='utf-8', mode='w+')
w = UnicodeWriter(open(filename.replace('.csv', '.plural.csv'), 'w'), headers)
w.writerow(dict([(h,h) for h in headers]))



def write_file(lines,fname):
    wf = open(fname, 'wb')
    wf.writelines(lines)
    wf.close()

def find_in_tree(tree, node):
    found = tree.find(node)
    if found == None:
        print "No %s in file" % node
        found = []
    return found

def extract_nbr(input_str):
    if input_str is None or input_str == '':
        return 0

    out_number = []
    for t in input_str.split("-",2):
        try:
            out_number.append(float(t))
        except ValueError:
            pass
    return out_number


antonyms_found = 0
data = collections.Counter()
list = []

for path, subdirs, files in os.walk(root):
    for name in files:
        if fnmatch(name, pattern):
            #print os.path.join(path, name)
            fr = open(path+"/"+name, 'r')
            DOMTree = xml.dom.minidom.parse(fr)
            collection = DOMTree.documentElement

            synset = collection.getElementsByTagName("m")
            #rootElement = ET.parse(path+"/"+name).getroot()
            #xmldoc = minidom.parse(path+"/"+name)
            #itemList = xmldoc.getElementsByTagName('SYNSET')

            print(len(synset))
            for s in synset:
                tag = s.getElementsByTagName('tag')[0]
                form = s.getElementsByTagName('form')[0]
                lemma = s.getElementsByTagName("lemma")[0]
                if (tag.childNodes[0].data== "NNNP4-----A----"): # "VpYS---XR-AA---", "NNNP4-----A----"
                    #print "Form = " + form.childNodes[0].data.lower()
                    #print "Lemma = " + lemma.childNodes[0].data.lower().split('_')[0]
                    data[lemma.childNodes[0].data.lower().split('_')[0]+","+form.childNodes[0].data.lower()] += 1



toPrint =data.most_common(300)
for word in toPrint:
    present = word[0].split(',')[0]
    past = word[0].split(',')[1]
    w.writerow({"podst.jm":present, "plural":past})
#print "Printing dictionary:\n"
#for s in data.items():
                #number_id = extract_nbr(id.childNodes[0].data)
                #literal = s.getElementsByTagName('LITERAL')[0]
                #data[int(number_id[0])] = literal.childNodes[0].data
                #data = data + {int(number_id[0]):literal.childNodes[0].data}

            # for s in synset:
            #     if s.getElementsByTagName('ILR'):
            #         #typeElements = s.getElementsByTagName('ILR')
            #         #type = s.getElementsByTagName('ILR')[0]
            #         ilr = s.getElementsByTagName('ILR')
            #         for antonym in ilr:
            #             if antonym.getElementsByTagName('TYPE'):
            #                 antonymCheck = antonym.getElementsByTagName('TYPE')[0]
            #                 if (antonymCheck.childNodes[0].data == "near_antonym"):
            #                     print "IDofAntonym: %s" % antonym.childNodes[0].data
            #                     literal = s.getElementsByTagName('LITERAL')[0]
            #                     literalID = antonym.childNodes[0].data
            #                     print "Literal: %s" % literal.childNodes[0].data
            #                     number_id = int(extract_nbr(antonym.childNodes[0].data)[0])
            #                     literal_antonym = data[number_id]
            #                     print " %s %s" % (literal.childNodes[0].data,literal_antonym)
            #                     if (literalID[-1]== 'n'):
            #                         w.writerow({"literal":literal.childNodes[0].data, "antonym":literal_antonym})
            #
            #                     #csvWriter.writerow([literal.childNodes[0].data,literal_antonym])
            #
            #                     antonyms_found += 1
            #for child in rootElement.findall('tag'):
             #   rank = child.find('AAFS2----1A----').text
             #   print child.attrib

