__author__ = 'svobik'
import csv, codecs, StringIO

class UnicodeWriter:
    """
    A CSV writer which will write rows to CSV file "f",
    which is encoded in the given encoding.
    """


    def __init__(self, f, fieldnames, restval='', extrasaction='raise', dialect='excel', encoding="utf-8", *args, **kwds):
        # Redirect output to a queue
        self.queue = StringIO.StringIO()
        self.writer = csv.DictWriter(self.queue, fieldnames=fieldnames, restval=restval, extrasaction=extrasaction,
                                     dialect=dialect, *args, **kwds)
        self.stream = f
        self.encoder = codecs.getincrementalencoder(encoding)()

    def writerow(self, row):
        self.writer.writerow(dict([(k.encode("utf-8"),v.encode("utf-8")) for (k,v) in row.items()]))
        # Fetch UTF-8 output from the queue ...
        data = self.queue.getvalue()
        data = data.decode("utf-8")
        # ... and reencode it into the target encoding
        data = self.encoder.encode(data)
        # write to the target stream
        self.stream.write(data)
        # empty queue
        self.queue.truncate(0)

    def writerows(self, rows):
        for row in rows:
            self.writerow(row)