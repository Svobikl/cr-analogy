__author__ = 'svobik'
import os
import csv, sys, codecs,cStringIO
from CsvWriter import UnicodeWriter
from fnmatch import fnmatch
from random import randint


pattern = "mesta_prezidenti.csv"
root = '/media/data/korpusy/Croatian/analogy/'

list=[]
list2=[]

headers = ['literal', 'antonym','literal','antonym']

def generateFromCSV():
    filename = 'output_corpus.txt'
    f = codecs.open(filename, encoding='utf-8', mode='w+')

    w = UnicodeWriter(open(filename.replace('.csv', '.csv'), 'w'), headers)
    #w.writerow(dict([(h,h) for h in headers]))
    rowlist =[]

    for path, subdirs, files in os.walk(root):
        for name in files:
            if fnmatch(name, pattern):
                print "Processing file: "+ name
                with open(path+"/"+name, 'rb') as f:
                    reader = csv.reader(f)
                    first = True


                    for row in reader:
                        if (first==False):
                            list.append(row)
                            list2.append(row)

                        first = False
                firstin = True
                first = True

                f = open('output2.txt','a')
                f.write(': '+name+'\n')
                for row in list:

                    for rowin in list2:
                        #print(len(row))
                        if (len(row)==3 and len(rowin)==3 and row != rowin):
                            rowlist = []
                            rowlist = row + rowin
                            index = randint(1,2)
                            #print (rowlist[0]+' '+rowlist[index-1]+' '+rowlist[3]+' '+rowlist[index+3-1])

                            #for s in row+rowin:
                           #    print(s+' ')
                           #    f.write(s+' ')
                            # f.write(rowlist[0]+' '+rowlist[3]+' '+rowlist[4]+' '+rowlist[7])
                            f.write(rowlist[0]+' '+rowlist[2]+' '+rowlist[3]+' '+rowlist[5])
                            f.write('\n')
                        firstin=False
                firstin = True

                list= []
                list2= []


def generateFromTxtFile():

    filename = 'output_corpus.txt'
    #f = codecs.open(filename, encoding='utf-8', mode='w+')

    #w = UnicodeWriter(open(filename.replace('.csv', '.csv'), 'w'), headers)
    #w.writerow(dict([(h,h) for h in headers]))
    rowlist =[]
    list=[]
    list2=[]
    f = open('output.txt','w')
    for path, subdirs, files in os.walk(root):
        for name in files:
            print "Processing file: "+ name
            with open(path+"/"+name, 'r') as f2:
                for row in f2:
                        list.append(row)
                        list2.append(row)
                f.write(': '+name+'\n')

            #f = open('output2.txt','a')

            for row in list:

                for rowin in list2:
                    #print(len(row))
                    if (row != rowin):
                        rowline = row.strip() +' '+ rowin.strip()
                        print(rowline)
                        f.write(rowline+ "\n")


            list= []
            list2= []

    f.close()

if __name__ == '__main__':

    generateFromTxtFile()